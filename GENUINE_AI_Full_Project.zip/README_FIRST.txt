GENUINE AI — Android project + secure AI backend starter
========================================================

WHAT IS INCLUDED
- Android app in Kotlin + Jetpack Compose
- First-launch language choice: English, Telugu, Hindi
- Ask anything text chat
- Photo picker and image-to-AI request support
- Simple / detailed explanation modes
- Text-to-speech read aloud
- Android speech-to-text input (device support required)
- Local recent conversation history
- Settings/language switching
- Node.js backend template that keeps the Gemini API key on the server
- Setup notes

IMPORTANT STATUS
This is a source project, not a finished APK. It has not been built or tested on your Windows computer.
The Android app UI and local functions are implemented. AI requests will work only after you deploy the backend,
put your own backend HTTPS URL in ApiConfig.kt, and configure a Gemini API key on that server.
The backend is a starter template; it is not hosted for you.
No API key is included. NEVER put a private API key in Android source code or share it in chat.

FREE USE / PRIVACY
Gemini currently lists a free tier for selected models, but it has rate limits and availability can change.
Google's free-tier pricing page says submitted content may be used to improve its products.
Do not upload private, sensitive, or identifying photos. Check the provider's current terms before using it.
Free AI is not unlimited. This app does not impose its own daily upload counter, but the AI provider can limit requests.

STEP A — INSTALL ANDROID STUDIO
1. On Windows 10 64-bit, download Android Studio from:
   https://developer.android.com/studio
2. Install using Standard setup and allow Android SDK downloads.
3. Extract this ZIP.
4. In Android Studio choose Open, then select the GENUINE_AI_Full_Project folder.
5. Wait for Gradle sync. If Android Studio asks to install SDK 35, accept.
6. Connect your Android phone by USB, enable USB debugging, approve the computer, and press Run.

STEP B — CONNECT THE AI BACKEND
The backend folder contains server.js and package.json.
It requires Node.js 20+ and a hosting service that supports Node.js and HTTPS.
1. Install Node.js LTS from https://nodejs.org/
2. Open a terminal in the backend folder.
3. Run: npm install
4. Set environment variable GEMINI_API_KEY on the server (not in the app).
5. Start locally with: npm start
6. For a real phone to reach a local computer server, both must be on the same Wi-Fi and use the computer's LAN IP.
   For production, deploy to a trusted HTTPS host.
7. Set API_BASE_URL in app/src/main/java/com/genuineai/app/ApiConfig.kt to your HTTPS backend URL.
8. Rebuild the app.

A parent/guardian should help with online accounts, API keys, and any service that asks for billing or age verification.
Do not add a payment method just to test the free tier.

BACKEND ENVIRONMENT
GEMINI_API_KEY=your_key_set_on_server
PORT=8080
GEMINI_MODEL=gemini-2.5-flash-lite

The model name and free-tier availability can change. Check:
https://ai.google.dev/gemini-api/docs/pricing

KNOWN LIMITATIONS
- The app is not published to Google Play.
- Auto-update is not active until you publish through a distribution channel (e.g. Google Play).
- Live web search/current news grounding is not yet implemented; model answers may be out of date.
- Voice recognition depends on the Android device's speech services and language availability.
- Conversation history is stored locally on the device only.
- No user account, cloud sync, or admin dashboard is included.
