import express from "express";

const app = express();
app.use(express.json({ limit: "12mb" }));

const API_KEY = process.env.GEMINI_API_KEY;
const MODEL = process.env.GEMINI_MODEL || "gemini-2.5-flash-lite";

app.get("/health", (_req, res) => res.json({ ok: true, service: "GENUINE AI backend" }));

app.post("/api/chat", async (req, res) => {
  try {
    if (!API_KEY) return res.status(503).json({ error: "Server administrator has not configured the AI key." });

    const { prompt = "", language = "english", mode = "simple", imageBase64, mimeType } = req.body ?? {};
    if (!String(prompt).trim() && !imageBase64) {
      return res.status(400).json({ error: "Enter a question or attach a photo." });
    }

    const languageName = ({ english: "English", telugu: "Telugu", hindi: "Hindi" })[language] || "English";
    const modeInstruction = mode === "detailed"
      ? "Give a thorough, well-organized explanation with headings, examples, important details, and a short summary."
      : "Explain in very simple, beginner-friendly language. Use short sentences and a small example where helpful.";

    const instruction = [
      `You are GENUINE AI, a helpful general knowledge and photo explanation assistant.`,
      `Answer in ${languageName}.`,
      modeInstruction,
      `Be accurate and distinguish verified facts from uncertainty. Do not pretend to have live internet access.`,
      `For health, legal, and financial topics, give general educational information and encourage consulting a qualified professional for important decisions.`,
      `If an image is supplied, describe only what can reasonably be observed, explain likely meaning and state uncertainty where needed.`,
      `User question: ${String(prompt).slice(0, 12000) || "Please explain the uploaded image in detail."}`
    ].join("\n\n");

    const parts = [{ text: instruction }];
    if (imageBase64) {
      if (!["image/jpeg", "image/png", "image/webp"].includes(mimeType)) {
        return res.status(400).json({ error: "Supported image formats are JPEG, PNG and WebP." });
      }
      parts.push({ inline_data: { mime_type: mimeType, data: imageBase64 } });
    }

    const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(MODEL)}:generateContent?key=${encodeURIComponent(API_KEY)}`;
    const upstream = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ role: "user", parts }],
        generationConfig: { temperature: 0.4, maxOutputTokens: mode === "detailed" ? 4096 : 2048 }
      })
    });

    const data = await upstream.json();
    if (!upstream.ok) {
      const msg = data?.error?.message || `AI provider returned HTTP ${upstream.status}`;
      return res.status(upstream.status).json({ error: msg });
    }

    const answer = data?.candidates?.[0]?.content?.parts
      ?.map(p => p.text || "")
      .join("\n")
      .trim();

    if (!answer) return res.status(502).json({ error: "The AI provider returned no text." });
    return res.json({ answer, model: MODEL });
  } catch (error) {
    console.error("Request failed:", error?.message || error);
    return res.status(500).json({ error: "The server could not complete this request." });
  }
});

const port = Number(process.env.PORT || 8080);
app.listen(port, () => console.log(`GENUINE AI backend listening on ${port}`));
