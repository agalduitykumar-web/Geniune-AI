package com.genuineai.app

/**
 * Replace this with your deployed HTTPS backend URL.
 * Do not put a Gemini API key in this Android app.
 */
object ApiConfig {
    const val API_BASE_URL = "https://YOUR-BACKEND-URL.example"
    const val CHAT_PATH = "/api/chat"
}
