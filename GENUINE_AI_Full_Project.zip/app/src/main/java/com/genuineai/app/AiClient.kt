package com.genuineai.app

import android.graphics.Bitmap
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

object AiClient {
    suspend fun ask(
        prompt: String,
        language: AppLanguage,
        mode: ExplanationMode,
        bitmap: Bitmap?
    ): String = withContext(Dispatchers.IO) {
        require(ApiConfig.API_BASE_URL.startsWith("https://") &&
                !ApiConfig.API_BASE_URL.contains("YOUR-BACKEND")) {
            "AI backend is not connected yet. Set your HTTPS backend URL in ApiConfig.kt."
        }

        val body = JSONObject().apply {
            put("prompt", prompt)
            put("language", language.name.lowercase())
            put("mode", mode.name.lowercase())
            if (bitmap != null) {
                val scaled = scaleBitmap(bitmap, 1280)
                val bytes = ByteArrayOutputStream().use { out ->
                    scaled.compress(Bitmap.CompressFormat.JPEG, 82, out)
                    out.toByteArray()
                }
                put("imageBase64", Base64.encodeToString(bytes, Base64.NO_WRAP))
                put("mimeType", "image/jpeg")
            }
        }

        val connection = (URL(ApiConfig.API_BASE_URL.trimEnd('/') + ApiConfig.CHAT_PATH)
            .openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 60000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }

        try {
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream.bufferedReader().use { it.readText() }
            val json = JSONObject(response)
            if (code !in 200..299) {
                throw IllegalStateException(json.optString("error", "AI request failed (HTTP $code)."))
            }
            json.optString("answer").ifBlank { "The AI service returned an empty answer." }
        } finally {
            connection.disconnect()
        }
    }

    private fun scaleBitmap(source: Bitmap, maxSide: Int): Bitmap {
        val largest = maxOf(source.width, source.height)
        if (largest <= maxSide) return source
        val ratio = maxSide.toFloat() / largest
        return Bitmap.createScaledBitmap(
            source,
            (source.width * ratio).toInt().coerceAtLeast(1),
            (source.height * ratio).toInt().coerceAtLeast(1),
            true
        )
    }
}
