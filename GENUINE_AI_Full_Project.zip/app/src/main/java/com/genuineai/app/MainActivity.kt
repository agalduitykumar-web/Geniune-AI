package com.genuineai.app

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import org.json.JSONArray
import java.util.Locale

private val Navy = Color(0xFF101827)
private val Blue = Color(0xFF2563EB)
private val Background = Color(0xFFF6F8FC)

enum class AppLanguage(val display: String, val native: String, val promptName: String) {
    ENGLISH("English", "English", "English"),
    TELUGU("Telugu", "తెలుగు", "Telugu"),
    HINDI("Hindi", "हिन्दी", "Hindi")
}
enum class ExplanationMode { SIMPLE, DETAILED }
data class ChatItem(val question: String, val answer: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("genuine_ai", MODE_PRIVATE)
        setContent {
            var language by remember {
                mutableStateOf(prefs.getString("language", null)?.let {
                    runCatching { AppLanguage.valueOf(it) }.getOrNull()
                })
            }
            MaterialTheme(
                colorScheme = lightColorScheme(primary = Blue, background = Background, surface = Color.White)
            ) {
                if (language == null) {
                    LanguageScreen { chosen ->
                        language = chosen
                        prefs.edit().putString("language", chosen.name).apply()
                    }
                } else {
                    GenuineHome(
                        language = language!!,
                        onLanguageChange = { chosen ->
                            language = chosen
                            prefs.edit().putString("language", chosen.name).apply()
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun LanguageScreen(onChoose: (AppLanguage) -> Unit) {
    Surface(Modifier.fillMaxSize(), color = Navy) {
        Column(
            Modifier.fillMaxSize().padding(26.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(Icons.Default.AutoAwesome, null, tint = Color.White, modifier = Modifier.size(66.dp))
            Spacer(Modifier.height(16.dp))
            Text("GENUINE AI", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text("See it. Understand it. Learn it.", color = Color(0xFFCBD5E1))
            Spacer(Modifier.height(42.dp))
            Text("Choose your language", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(18.dp))
            AppLanguage.values().forEach { lang ->
                Button(
                    onClick = { onChoose(lang) },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Navy),
                    shape = RoundedCornerShape(15.dp)
                ) { Text(lang.native, fontSize = 18.sp, modifier = Modifier.padding(5.dp)) }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun GenuineHome(language: AppLanguage, onLanguageChange: (AppLanguage) -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("genuine_ai", ComponentActivity.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    var prompt by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf(ExplanationMode.SIMPLE) }
    var photoUri by remember { mutableStateOf<Uri?>(null) }
    var photoBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var showLanguage by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }
    var history by remember { mutableStateOf(loadHistory(prefs)) }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }

    DisposableEffect(context) {
        val engine = TextToSpeech(context) { }
        tts = engine
        onDispose { engine.stop(); engine.shutdown() }
    }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        photoUri = uri
        photoBitmap = null
        error = ""
        if (uri != null) {
            runCatching {
                context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            }.onSuccess { photoBitmap = it }
             .onFailure { error = "Could not open this photo. Please choose another image." }
        }
    }

    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) prompt = spoken
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("GENUINE AI", fontWeight = FontWeight.Bold)
                        Text("Your world of knowledge", fontSize = 12.sp, color = Color.Gray)
                    }
                },
                actions = {
                    IconButton(onClick = { showHistory = true }) { Icon(Icons.Default.History, "History") }
                    Box {
                        IconButton(onClick = { showLanguage = true }) { Icon(Icons.Default.Language, "Language") }
                        DropdownMenu(showLanguage, { showLanguage = false }) {
                            AppLanguage.values().forEach { lang ->
                                DropdownMenuItem(
                                    text = { Text(lang.native) },
                                    onClick = { showLanguage = false; onLanguageChange(lang) }
                                )
                            }
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Card(colors = CardDefaults.cardColors(containerColor = Navy), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.fillMaxWidth().padding(20.dp)) {
                    Text("Hello! 👋", color = Color(0xFFBFDBFE))
                    Spacer(Modifier.height(5.dp))
                    Text("What would you like to understand?", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(7.dp))
                    Text("Ask a question or upload a photo.", color = Color(0xFFCBD5E1))
                }
            }

            Text("Ask anything", fontSize = 19.sp, fontWeight = FontWeight.Bold)
            OutlinedTextField(
                value = prompt,
                onValueChange = { prompt = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Ask about science, history, technology, business...") },
                minLines = 3,
                shape = RoundedCornerShape(16.dp),
                trailingIcon = {
                    IconButton(onClick = {
                        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, when (language) {
                                AppLanguage.TELUGU -> "te-IN"
                                AppLanguage.HINDI -> "hi-IN"
                                else -> "en-IN"
                            })
                        }
                        runCatching { speechLauncher.launch(intent) }
                            .onFailure { error = "Speech input is not available on this device." }
                    }) { Icon(Icons.Default.Mic, "Speak") }
                }
            )

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Explanation", fontWeight = FontWeight.SemiBold)
                FilterChip(mode == ExplanationMode.SIMPLE, { mode = ExplanationMode.SIMPLE }, label = { Text("Simple") })
                FilterChip(mode == ExplanationMode.DETAILED, { mode = ExplanationMode.DETAILED }, label = { Text("Detailed") })
            }

            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF4FF)), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AddPhotoAlternate, null, tint = Blue)
                        Spacer(Modifier.width(8.dp))
                        Text("Understand a photo", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                    Text("Choose a picture of a document, diagram, object, plant, place or other subject.")
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(
                        onClick = { photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.PhotoLibrary, null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (photoUri == null) "Choose photo" else "Choose another photo")
                    }
                    photoBitmap?.let {
                        Spacer(Modifier.height(10.dp))
                        Image(
                            bitmap = it.asImageBitmap(),
                            contentDescription = "Selected photo",
                            modifier = Modifier.fillMaxWidth().heightIn(max = 240.dp),
                            contentScale = ContentScale.Fit
                        )
                    }
                }
            }

            Button(
                enabled = !busy,
                onClick = {
                    if (prompt.isBlank() && photoBitmap == null) {
                        error = "Type a question or select a photo first."
                    } else {
                        busy = true
                        error = ""
                        scope.launch {
                            try {
                                val result = AiClient.ask(
                                    prompt.ifBlank { "Please describe and explain this photo." },
                                    language, mode, photoBitmap
                                )
                                val item = ChatItem(prompt.ifBlank { "Photo explanation" }, result)
                                history = listOf(item) + history
                                saveHistory(prefs, history)
                                prompt = ""
                                photoUri = null
                                photoBitmap = null
                                error = "ANSWER_READY"
                                // Speak is optional; answer appears in the history panel.
                            } catch (e: Exception) {
                                error = e.message ?: "Could not connect to the AI service."
                            } finally {
                                busy = false
                            }
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(15.dp)
            ) {
                if (busy) CircularProgressIndicator(Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                else Icon(Icons.Default.AutoAwesome, null)
                Spacer(Modifier.width(8.dp))
                Text(if (busy) "Thinking..." else "Explain with AI", fontSize = 16.sp)
            }

            if (error.isNotBlank() && error != "ANSWER_READY") {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF1F0))) {
                    Text(error, Modifier.padding(13.dp), color = Color(0xFF9F2D25))
                }
            }
            if (history.isNotEmpty()) {
                Text("Latest explanation", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Card(shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.fillMaxWidth().padding(15.dp)) {
                        Text(history.first().question, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))
                        Text(history.first().answer)
                        Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                            TextButton(onClick = {
                                tts?.language = when (language) {
                                    AppLanguage.TELUGU -> Locale("te", "IN")
                                    AppLanguage.HINDI -> Locale("hi", "IN")
                                    else -> Locale.US
                                }
                                tts?.speak(history.first().answer, TextToSpeech.QUEUE_FLUSH, null, "genuine-answer")
                            }) {
                                Icon(Icons.Default.VolumeUp, null); Text(" Read aloud")
                            }
                        }
                    }
                }
            }
            Text("Language: ${language.display}", color = Color.Gray, fontSize = 12.sp)
            Text(
                "History stays on this phone. AI processing requires your own secure backend connection.",
                color = Color.Gray, fontSize = 12.sp
            )
            Spacer(Modifier.height(18.dp))
        }
    }

    if (showHistory) {
        AlertDialog(
            onDismissRequest = { showHistory = false },
            title = { Text("Recent history") },
            text = {
                if (history.isEmpty()) Text("No saved explanations yet.")
                else LazyColumn(Modifier.heightIn(max = 420.dp)) {
                    items(history) { item ->
                        Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                            Text(item.question, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(4.dp))
                            Text(item.answer)
                            Divider(Modifier.padding(top = 8.dp))
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showHistory = false }) { Text("Close") } },
            dismissButton = {
                TextButton(onClick = {
                    history = emptyList()
                    saveHistory(prefs, history)
                }) { Text("Clear history") }
            }
        )
    }
}

private fun loadHistory(prefs: android.content.SharedPreferences): List<ChatItem> {
    return runCatching {
        val array = JSONArray(prefs.getString("history", "[]"))
        (0 until array.length()).map { i ->
            val obj = array.getJSONObject(i)
            ChatItem(obj.optString("question"), obj.optString("answer"))
        }
    }.getOrDefault(emptyList())
}

private fun saveHistory(prefs: android.content.SharedPreferences, history: List<ChatItem>) {
    val array = JSONArray()
    history.take(30).forEach { item ->
        array.put(org.json.JSONObject().put("question", item.question).put("answer", item.answer))
    }
    prefs.edit().putString("history", array.toString()).apply()
}
